-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.25-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table _a.account
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `sha_pass_hash` varchar(40) NOT NULL DEFAULT '',
  `sessionkey` varchar(80) NOT NULL DEFAULT '',
  `v` varchar(64) NOT NULL DEFAULT '',
  `s` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Account System';

-- Dumping data for table _a.account: ~6 rows (approximately)
DELETE FROM `account`;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `username`, `sha_pass_hash`, `sessionkey`, `v`, `s`, `email`, `joindate`, `last_ip`, `failed_logins`, `locked`, `last_login`, `online`, `expansion`, `mutetime`, `mutereason`, `muteby`, `locale`, `os`, `recruiter`) VALUES
	(1, '1', '3E774731D33D9224AC36AF3D85BA1F81B31BC84D', 'E34C2F70C8DE92A50A741202B2FB2923EEBDCB258957CFFB85CA5DBCC09EE2703F18F47C7AB257E2', '70945999110A1DB9620CF6F2332AF928B03009774559DFCF33741311D9FDA0EB', 'CD734FE1C2F5C7486EFB618F83F9C1DF233D22D7E5AA401FA534969372D9FE69', '', '2017-10-04 17:17:10', '127.0.0.1', 0, 0, '2017-10-17 02:41:10', 0, 3, 0, '', '', 0, 'Win', 0),
	(2, '2', '7A27A0AE0E194CB42B35610C81EB3644AC62270C', '9096EF17751CD1793A722722C19920985B2786273951577D443F88260E7CD044F3C37BAC1E5113ED', '3A50D32C4D7BDCC5E9C954A0C739F9406CEB19F30615B206DA0172336121E81B', 'DA3887DA1AB7D4ABB92B7717FF42A330CEA697C2E17AA1F8E8834BBBA87C2D6F', '', '2017-10-04 17:17:12', '127.0.0.1', 0, 0, '2017-10-14 03:25:32', 0, 3, 0, '', '', 0, 'Win', 0),
	(3, '3', '110F747D635318070FA5FBB216F32C7BE8B5F811', '1735B6EE7147706DD97D42EE159DCEEA4215380782AC02F65A36E20FB8BB1DD3C8DE5106C92D71F1', '735D5759FD29BFEB6E617ADF641C389342A9286E6910900480BCEBDB500636DC', 'D63D48726FC9B08A4AF5F09F48984D9B12A714652836275CB3D382605BDAB85B', '', '2017-10-04 17:17:14', '127.0.0.1', 0, 0, '2017-10-15 19:39:21', 0, 3, 0, '', '', 0, 'Win', 0),
	(4, '4', '035B5C8BBE906BFE1792E270A0964E9FEA52A4BA', '', '', '', '', '2017-10-04 17:17:16', '127.0.0.1', 0, 0, '0000-00-00 00:00:00', 0, 3, 0, '', '', 0, '', 0),
	(5, '5', '6D761AA0787BC5B7AC9B8FD24BD6E06BD8A867F6', '', '', '', '', '2017-10-04 17:17:17', '127.0.0.1', 0, 0, '0000-00-00 00:00:00', 0, 3, 0, '', '', 0, '', 0),
	(6, '6', 'EDD97AC340F09FA837390E34AA917C895D4EC56D', '', '', '', '', '2017-10-04 17:17:19', '127.0.0.1', 0, 0, '0000-00-00 00:00:00', 0, 3, 0, '', '', 0, '', 0);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;

-- Dumping structure for table _a.account_access
CREATE TABLE IF NOT EXISTS `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  `comment` text NOT NULL,
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table _a.account_access: ~6 rows (approximately)
DELETE FROM `account_access`;
/*!40000 ALTER TABLE `account_access` DISABLE KEYS */;
INSERT INTO `account_access` (`id`, `gmlevel`, `RealmID`, `comment`) VALUES
	(1, 6, -1, ''),
	(2, 6, -1, ''),
	(3, 6, -1, ''),
	(4, 6, -1, ''),
	(5, 6, -1, ''),
	(6, 6, -1, '');
/*!40000 ALTER TABLE `account_access` ENABLE KEYS */;

-- Dumping structure for table _a.account_banned
CREATE TABLE IF NOT EXISTS `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';

-- Dumping data for table _a.account_banned: ~0 rows (approximately)
DELETE FROM `account_banned`;
/*!40000 ALTER TABLE `account_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_banned` ENABLE KEYS */;

-- Dumping structure for table _a.autobroadcast
CREATE TABLE IF NOT EXISTS `autobroadcast` (
  `realmid` int(11) NOT NULL DEFAULT '-1',
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `weight` tinyint(3) unsigned DEFAULT '1',
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`,`realmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table _a.autobroadcast: ~0 rows (approximately)
DELETE FROM `autobroadcast`;
/*!40000 ALTER TABLE `autobroadcast` DISABLE KEYS */;
/*!40000 ALTER TABLE `autobroadcast` ENABLE KEYS */;

-- Dumping structure for table _a.ip_banned
CREATE TABLE IF NOT EXISTS `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Banned IPs';

-- Dumping data for table _a.ip_banned: ~0 rows (approximately)
DELETE FROM `ip_banned`;
/*!40000 ALTER TABLE `ip_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_banned` ENABLE KEYS */;

-- Dumping structure for table _a.realmcharacters
CREATE TABLE IF NOT EXISTS `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Realm Character Tracker';

-- Dumping data for table _a.realmcharacters: ~6 rows (approximately)
DELETE FROM `realmcharacters`;
/*!40000 ALTER TABLE `realmcharacters` DISABLE KEYS */;
INSERT INTO `realmcharacters` (`realmid`, `acctid`, `numchars`) VALUES
	(1, 1, 6),
	(1, 2, 1),
	(1, 3, 1),
	(1, 4, 0),
	(1, 5, 0),
	(1, 6, 0);
/*!40000 ALTER TABLE `realmcharacters` ENABLE KEYS */;

-- Dumping structure for table _a.realmlist
CREATE TABLE IF NOT EXISTS `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '12340',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Realm System';

-- Dumping data for table _a.realmlist: ~1 rows (approximately)
DELETE FROM `realmlist`;
/*!40000 ALTER TABLE `realmlist` DISABLE KEYS */;
INSERT INTO `realmlist` (`id`, `name`, `address`, `localAddress`, `localSubnetMask`, `port`, `icon`, `flag`, `timezone`, `allowedSecurityLevel`, `population`, `gamebuild`) VALUES
	(1, 'Trinity', '127.0.0.1', '127.0.0.1', '255.255.255.0', 8085, 1, 1, 8, 0, 0, 12340);
/*!40000 ALTER TABLE `realmlist` ENABLE KEYS */;

-- Dumping structure for table _a.uptime
CREATE TABLE IF NOT EXISTS `uptime` (
  `realmid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `uptime` int(10) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'Trinitycore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Uptime system';

-- Dumping data for table _a.uptime: ~98 rows (approximately)
DELETE FROM `uptime`;
/*!40000 ALTER TABLE `uptime` DISABLE KEYS */;
INSERT INTO `uptime` (`realmid`, `starttime`, `uptime`, `maxplayers`, `revision`) VALUES
	(1, 1507126518, 601, 1, ''),
	(1, 1507128363, 1506, 1, ''),
	(1, 1507129969, 1846, 2, ''),
	(1, 1507131850, 279, 1, ''),
	(1, 1507132220, 242, 1, ''),
	(1, 1507133267, 3902, 1, ''),
	(1, 1507137255, 463, 1, ''),
	(1, 1507137793, 1502, 1, ''),
	(1, 1507233740, 232, 1, ''),
	(1, 1507234041, 336, 0, ''),
	(1, 1507409154, 0, 0, ''),
	(1, 1507409239, 483, 1, ''),
	(1, 1507409753, 182, 1, ''),
	(1, 1507409954, 122, 0, ''),
	(1, 1507410139, 0, 0, ''),
	(1, 1507410224, 121, 1, ''),
	(1, 1507410407, 241, 1, ''),
	(1, 1507476314, 166, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507476534, 0, 0, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507476570, 0, 0, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507477656, 122, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507477816, 0, 0, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507477892, 301, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507478213, 62, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507478328, 841, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507479204, 61, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507479315, 362, 1, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507479701, 242, 0, 'PB ver. Sun, 8 Oct 2017 18:04:53 +0300 (152b98d) (Win64, ???)'),
	(1, 1507480239, 136, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507480403, 396, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507480890, 95, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507481050, 0, 0, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507481091, 144, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507481282, 334, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507481871, 325, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507482439, 3662, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507494563, 875, 1, 'PB ver. Sun, 8 Oct 2017 19:27:26 +0300 (e15068c) (Win64, ???)'),
	(1, 1507496026, 481, 2, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507496614, 697, 2, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507497378, 271, 2, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507497690, 0, 0, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507497718, 721, 2, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507498522, 461, 0, 'PB ver. Sun, 8 Oct 2017 23:47:54 +0300 (fe321e7) (Win64, ???)'),
	(1, 1507499041, 308, 1, 'PB ver. Mon, 9 Oct 2017 00:37:00 +0300 (887ec7c) (Win64, ???)'),
	(1, 1507499405, 121, 1, 'PB ver. Mon, 9 Oct 2017 00:37:00 +0300 (887ec7c) (Win64, ???)'),
	(1, 1507499936, 2341, 1, 'PB ver. Mon, 9 Oct 2017 00:56:49 +0300 (42c7fb0) (Win64, ???)'),
	(1, 1507560123, 493, 1, 'PB ver. Mon, 9 Oct 2017 00:56:49 +0300 (42c7fb0) (Win64, ???)'),
	(1, 1507560669, 1561, 1, 'PB ver. Mon, 9 Oct 2017 00:56:49 +0300 (42c7fb0) (Win64, ???)'),
	(1, 1507562265, 18962, 1, 'PB ver. Mon, 9 Oct 2017 00:56:49 +0300 (42c7fb0) (Win64, ???)'),
	(1, 1507696355, 5754, 1, 'PB ver. Mon, 9 Oct 2017 00:56:49 +0300 (42c7fb0) (Win64, ???)'),
	(1, 1507731310, 131, 1, 'PB ver. Wed, 11 Oct 2017 17:10:50 +0300 (0241f6e) (Win64, ???)'),
	(1, 1507735234, 312, 1, 'PB ver. Wed, 11 Oct 2017 17:24:05 +0300 (9609649) (Win64, ???)'),
	(1, 1507738359, 182, 1, 'PB ver. Wed, 11 Oct 2017 17:24:05 +0300 (9609649) (Win64, ???)'),
	(1, 1507739044, 182, 1, 'PB ver. Wed, 11 Oct 2017 17:24:05 +0300 (9609649) (Win64, ???)'),
	(1, 1507739323, 0, 0, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507739492, 243, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507739807, 2641, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507743164, 61, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507743399, 661, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507744138, 1981, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507748923, 301, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507766734, 3362, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507809856, 198, 0, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507810161, 101281, 1, 'PB ver. Wed, 11 Oct 2017 19:25:41 +0300 (b7d157b) (Win64, ???)'),
	(1, 1507935219, 290, 2, 'PB ver. Sat, 14 Oct 2017 01:50:23 +0300 (5110034) (Win64, ???)'),
	(1, 1507936587, 0, 0, 'PB ver. Sat, 14 Oct 2017 01:50:23 +0300 (5110034) (Win64, ???)'),
	(1, 1507936652, 242, 1, 'PB ver. Sat, 14 Oct 2017 01:50:23 +0300 (5110034) (Win64, ???)'),
	(1, 1507936955, 782, 2, 'PB ver. Sat, 14 Oct 2017 01:50:23 +0300 (5110034) (Win64, ???)'),
	(1, 1507938016, 1081, 2, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507939185, 301, 2, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507939569, 541, 2, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507940155, 61, 2, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507940742, 1921, 2, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507942824, 121, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507943067, 0, 0, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507943128, 61, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507943227, 601, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944010, 0, 0, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944074, 242, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944377, 0, 0, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944505, 0, 0, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944621, 0, 0, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944726, 61, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507944858, 181, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507945124, 121, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1507945299, 121, 1, 'PB ver. Sat, 14 Oct 2017 02:34:06 +0300 (cc3f6b2) (Win64, ???)'),
	(1, 1508071491, 486, 1, 'PB ver. Sun, 15 Oct 2017 00:59:31 +0300 (941462d) (Win64, ???)'),
	(1, 1508074303, 7441, 0, 'PB ver. Sun, 15 Oct 2017 00:59:31 +0300 (941462d) (Win64, ???)'),
	(1, 1508081813, 8642, 2, 'PB ver. Sun, 15 Oct 2017 00:59:31 +0300 (941462d) (Win64, ???)'),
	(1, 1508091163, 662, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508093189, 241, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508093486, 65, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508094750, 121, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508094995, 546, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508095571, 181, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508096038, 0, 0, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508097435, 1075, 1, 'PB ver. Fri, 13 Oct 2017 21:21:48 +0300 (99ce945) (Win64, ???)'),
	(1, 1508126043, 0, 0, 'PB ver. Fri, 13 Oct 2017 21:21:48 +0300 (99ce945) (Win64, ???)'),
	(1, 1508126106, 0, 0, 'PB ver. Fri, 13 Oct 2017 21:21:48 +0300 (99ce945) (Win64, ???)'),
	(1, 1508126156, 95, 0, 'PB ver. Fri, 13 Oct 2017 21:21:48 +0300 (99ce945) (Win64, ???)'),
	(1, 1508169125, 0, 0, 'PB ver. Mon, 16 Oct 2017 18:19:55 +0300 (ead1240) (Win64, ???)'),
	(1, 1508195017, 225, 1, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508195288, 0, 0, 'PB ver. Sun, 15 Oct 2017 15:54:33 +0300 (0b6bf6b) (Win64, ???)'),
	(1, 1508197246, 61, 1, 'PB ver. Tue, 17 Oct 2017 02:10:27 +0300 (b422851) (Win64, ???)');
/*!40000 ALTER TABLE `uptime` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
