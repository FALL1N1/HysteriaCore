-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.30-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table _a.account
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `sha_pass_hash` varchar(40) NOT NULL DEFAULT '',
  `sessionkey` varchar(80) NOT NULL DEFAULT '',
  `v` varchar(64) NOT NULL DEFAULT '',
  `s` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  `free` int(10) unsigned NOT NULL DEFAULT '0',
  `premium` int(10) unsigned NOT NULL DEFAULT '0',
  `charlogin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Account System';

-- Dumping data for table _a.account: ~7 rows (approximately)
DELETE FROM `account`;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `username`, `sha_pass_hash`, `sessionkey`, `v`, `s`, `email`, `joindate`, `last_ip`, `failed_logins`, `locked`, `last_login`, `online`, `expansion`, `mutetime`, `mutereason`, `muteby`, `locale`, `os`, `recruiter`, `free`, `premium`, `charlogin`) VALUES
	(1, '1', '3E774731D33D9224AC36AF3D85BA1F81B31BC84D', '26133E0F8383BF737141A12ABEE9E92CC1F17595230989956F54B025023794D87A156C41DE58371A', '7FF8FC5713CFAE38BF41209C3DF6CB2FB21E6238BEB3262B16B53ECA75D98C76', 'F6895E12E59B69D01C7A2A0EA108DB81DC3F9A5F94B1410B1757F83958A5866D', '', '2018-02-10 18:59:01', '127.0.0.1', 0, 0, '2018-04-24 21:18:35', 0, 3, 0, '', '', 0, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(2, '2', '7A27A0AE0E194CB42B35610C81EB3644AC62270C', '3AD62B513F857ECBADD632FC08DDA8C81ADA4DC05F8CCD5E78751429430519C7D83A99F5DFE57B62', '17E5757689CAFA7E970204B26D0CCB7545617E45FAEF98699FD40291ADFB9FE3', 'F64F8C55275C1CBEC14DF42A93C01A7E3D761B73AC0EC39E26EE07D67ECA9789', '', '2018-02-13 19:09:07', '127.0.0.1', 0, 0, '2018-04-24 20:15:43', 0, 3, 0, '', '', 0, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(3, '3', '110F747D635318070FA5FBB216F32C7BE8B5F811', '9580E09C22E8B29DFA12E3FC27A6F61D1CF3E726D01EA081FAFDAD501DAB225C362B41CB1E15E29E', '444A9B54D92C61EC3A34E32E494DF24CD66F150BCE4FF98936910DFB258222AC', '8B021CA78B5E2299A30E2C5C60C59AC6A752FFC91B107EB8C56C5BEC171B7427', '', '2018-02-13 19:09:08', '127.0.0.1', 0, 0, '2018-03-03 19:38:09', 0, 3, 0, '', '', 0, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(4, '55', 'E8E66CEDF26470366F3D2A03428B04401AED78BA', 'DDD6B9EECAA7A6D518458348EC6A3BBA1184A3776C2AD5045C4A37DFD5CF776EE0F293DB73FEE10F', '0B44582E83C8D20C9C6DDEE132AE391527D7E41ED41DF72B01D9B8357656FDCE', '8ED255BD21EF5B8A4E8AFD186A79251396E8090E3219DE44DBCA207682359CDD', '', '2018-02-13 19:39:55', '127.0.0.1', 0, 0, '2018-02-14 00:17:53', 0, 3, 0, '', '', 0, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(5, '66', 'E05474F6B190A7FE701B43D8CFD1B09814CD1B71', '6F9EC1CA3921F25AD373EF885B11BB572A9C9760F2C31594CD6D6CE04C586B505408D5BC99F7A1B4', '67F092AF8D0C10A50BD524EAB23881BEA280286A13005CD6ED18BF0C65D83CD3', 'CB8E4C9EDD2EB28D7EF2767CFE0559D52219F93AB9DF68557238DCF7A25A0C23', '', '2018-02-13 19:39:58', '127.0.0.1', 0, 0, '2018-02-13 23:09:52', 0, 3, 0, '', '', 0, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(6, 'A', 'F3F8CD726DC80503B80218793EA0B5F2AB962612', 'E21DD3DABD81050256269ABAE97CABCA5A95431A333F1B3EB147A2F9D80CE7403D1A8662B17F7F63', '584FC24EBE3512887480AB72A8436D68CD9F48B3C9273FE2CA14A9126B7CCFD9', 'A4E98307E9DE64C698BA0CEFF211B928335E92DF2F2AE8FC858C44836574838B', '', '2018-03-03 19:12:07', '95.165.141.71', 0, 0, '2018-03-03 20:07:59', 0, 3, 0, '', '', 8, 'Win', 0, 0, 0, '0000-00-00 00:00:00'),
	(7, 'B', '4355DDC7A69400BD8376BD07720D50DDF7344209', '', '', '', '', '2018-03-03 19:12:23', '127.0.0.1', 0, 0, '0000-00-00 00:00:00', 0, 3, 0, '', '', 0, '', 0, 0, 0, '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;

-- Dumping structure for table _a.account_access
CREATE TABLE IF NOT EXISTS `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  `comment` text NOT NULL,
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table _a.account_access: ~4 rows (approximately)
DELETE FROM `account_access`;
/*!40000 ALTER TABLE `account_access` DISABLE KEYS */;
INSERT INTO `account_access` (`id`, `gmlevel`, `RealmID`, `comment`) VALUES
	(1, 25, -1, ''),
	(2, 25, -1, ''),
	(3, 25, -1, ''),
	(4, 25, -1, ''),
	(5, 25, -1, '');
/*!40000 ALTER TABLE `account_access` ENABLE KEYS */;

-- Dumping structure for table _a.account_banned
CREATE TABLE IF NOT EXISTS `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';

-- Dumping data for table _a.account_banned: ~0 rows (approximately)
DELETE FROM `account_banned`;
/*!40000 ALTER TABLE `account_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_banned` ENABLE KEYS */;

-- Dumping structure for table _a.account_free_character
CREATE TABLE IF NOT EXISTS `account_free_character` (
  `id` bigint(20) DEFAULT NULL,
  `character` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table _a.account_free_character: ~0 rows (approximately)
DELETE FROM `account_free_character`;
/*!40000 ALTER TABLE `account_free_character` DISABLE KEYS */;
INSERT INTO `account_free_character` (`id`, `character`) VALUES
	(1, 'Rsg');
/*!40000 ALTER TABLE `account_free_character` ENABLE KEYS */;

-- Dumping structure for table _a.autobroadcast
CREATE TABLE IF NOT EXISTS `autobroadcast` (
  `realmid` int(11) NOT NULL DEFAULT '-1',
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `weight` tinyint(3) unsigned DEFAULT '1',
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`,`realmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table _a.autobroadcast: ~0 rows (approximately)
DELETE FROM `autobroadcast`;
/*!40000 ALTER TABLE `autobroadcast` DISABLE KEYS */;
/*!40000 ALTER TABLE `autobroadcast` ENABLE KEYS */;

-- Dumping structure for table _a.ip_banned
CREATE TABLE IF NOT EXISTS `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Banned IPs';

-- Dumping data for table _a.ip_banned: ~0 rows (approximately)
DELETE FROM `ip_banned`;
/*!40000 ALTER TABLE `ip_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_banned` ENABLE KEYS */;

-- Dumping structure for table _a.realmcharacters
CREATE TABLE IF NOT EXISTS `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Realm Character Tracker';

-- Dumping data for table _a.realmcharacters: ~7 rows (approximately)
DELETE FROM `realmcharacters`;
/*!40000 ALTER TABLE `realmcharacters` DISABLE KEYS */;
INSERT INTO `realmcharacters` (`realmid`, `acctid`, `numchars`) VALUES
	(1, 1, 7),
	(1, 2, 2),
	(1, 3, 2),
	(1, 4, 1),
	(1, 5, 1),
	(1, 6, 1),
	(1, 7, 0);
/*!40000 ALTER TABLE `realmcharacters` ENABLE KEYS */;

-- Dumping structure for table _a.realmlist
CREATE TABLE IF NOT EXISTS `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '12340',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Realm System';

-- Dumping data for table _a.realmlist: ~1 rows (approximately)
DELETE FROM `realmlist`;
/*!40000 ALTER TABLE `realmlist` DISABLE KEYS */;
INSERT INTO `realmlist` (`id`, `name`, `address`, `localAddress`, `localSubnetMask`, `port`, `icon`, `flag`, `timezone`, `allowedSecurityLevel`, `population`, `gamebuild`) VALUES
	(1, 'Trinity', '37.157.162.182', '127.0.0.1', '255.255.255.0', 8085, 1, 1, 1, 0, 0, 12340);
/*!40000 ALTER TABLE `realmlist` ENABLE KEYS */;

-- Dumping structure for table _a.server_bonuspoints
CREATE TABLE IF NOT EXISTS `server_bonuspoints` (
  `balance` bigint(20) DEFAULT NULL,
  `lastpurchase` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table _a.server_bonuspoints: ~0 rows (approximately)
DELETE FROM `server_bonuspoints`;
/*!40000 ALTER TABLE `server_bonuspoints` DISABLE KEYS */;
INSERT INTO `server_bonuspoints` (`balance`, `lastpurchase`) VALUES
	(0, '2018-03-03 20:19:55');
/*!40000 ALTER TABLE `server_bonuspoints` ENABLE KEYS */;

-- Dumping structure for table _a.uptime
CREATE TABLE IF NOT EXISTS `uptime` (
  `realmid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `uptime` int(10) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'Trinitycore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Uptime system';

-- Dumping data for table _a.uptime: ~0 rows (approximately)
DELETE FROM `uptime`;
/*!40000 ALTER TABLE `uptime` DISABLE KEYS */;
/*!40000 ALTER TABLE `uptime` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
